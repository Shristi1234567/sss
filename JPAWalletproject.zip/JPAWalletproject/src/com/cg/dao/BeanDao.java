package com.cg.dao;

import com.cg.bean.Bean;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class BeanDao {
	
	//to add a account in a table
	public void addUser(Bean e)
	{
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform insert operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		em.getTransaction().begin();//begin the transaction
		em.persist(e);//persist is equal to insert query
		em.getTransaction().commit();//commit the transaction
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
			}
	}
	
	//to display the data from the table
	 public double display(long accno)
	 {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform retrieving operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		Bean au=em.find(Bean.class, accno);
		if(au!=null)
		{
			return au.getBalance();
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally 
		{
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
		}
		return (Double) null;
	 }
	
	 //to deposit the amount in your account
	public boolean deposit(long accno,double balance)
	{
		boolean res = false;
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform retrieving operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		em.getTransaction().begin();//begin the transaction
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally 
		{
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
		}
		return res;
	
	}
}
/* public boolean deposit(long accno,double balance) {
	 boolean res = false;
	 try {
			con = CreateConnection.getConnection();//call the connection
			String sql = "update bankusers set balance=balance+? where accno=?";
			ps = con.prepareStatement(sql);
			ps.setDouble(1, balance);
			ps.setLong(2, accno);
			ps.executeUpdate();
			res = true;
		}
		catch(SQLException e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();//close the connection
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your connection is not properly closed.");
				}
			}
		}
	 return res;
 }*/
 
 //to withdraw the amount from your account
/* public boolean Withdraw(long accno,double balance) {
	 boolean res = false;
	 try {
			con = CreateConnection.getConnection();//call the connection
			String sql1 = "select balance from bankusers where accno=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, accno);
			rs = ps.executeQuery();
			rs.next();
			Double bal = rs.getDouble("balance");
			if(bal<balance) {
				return res;
			}
			String sql2 = "update bankusers set balance=balance-? where accno=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, balance);
			ps.setLong(2, accno);
			ps.executeUpdate();
			res = true;
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		finally {
			if(con!=null && ps!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your connection is not properly closed.");
				}
			}
		}
		return res;
 }*/
 
 //to transfer the fund from one account to another account
/* public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount) {
	 boolean res = false;
	 try {
			con = CreateConnection.getConnection();//call the connection
			String sql1 = "select balance from bankusers where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, sourceaccno);
			rs = ps.executeQuery();
			if(rs.next()==false)
				return res;
			Double bal = rs.getDouble("balance");
			if(bal<transferamount)
				return res;
			String sql2 = "update bankusers set balance=balance-? where accNo=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, transferamount);
			ps.setLong(2, sourceaccno);
			ps.executeUpdate();
			String sql3 = "update bankusers set balance=balance+? where accNo=?";
			ps= con.prepareStatement(sql3);
			ps.setDouble(1, transferamount);
			ps.setLong(2, destinationaccno);
			row = ps.executeUpdate();
			if(row<1)
				return res;
			else
				res = true;
		}
		catch(SQLException e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();//close the connection
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your connection is not properly closed.");
				}
			}
		}
		return res;
 }*/


