package com.cg.service;

import java.util.Scanner;

import com.cg.bean.Bean;
import com.cg.dao.BeanDao;

public class BeanService {
	 BeanDao paydao=new BeanDao();//object of dao class
	 Scanner sc=new Scanner(System.in);
	
	
//to make a create function to create account
public void create(Bean p)
{
	paydao.addUser(p);//call the add user method in dao class
}

//to make a function to deposit in your account 
public boolean deposit(long accno,double balance)
{
	boolean res=false;
	res = paydao.deposit(accno, balance);//call the deposit method in dao class
	return res;
}

//to make a function to display 
public double display(long accno)
{
	double balance = paydao.display(accno);//call the display method
	return balance;
	
}


//to make a function to withdraw from your account
/*public boolean Withdraw(long accno,double balance)
{
	boolean res = paydao.Withdraw(accno, balance);//call the withdraw method
	return res;
}*/

//to make a function to transfer fund from one to another account
/*public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount)
{
	boolean r=false;
	r = paydao.transferFund(sourceaccno, destinationaccno, transferamount);//call the transferfund method
	return r;
}*/
}

	

	
	
	 
	



