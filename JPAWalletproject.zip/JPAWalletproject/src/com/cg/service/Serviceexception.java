package com.cg.service;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Serviceexception {
	Scanner sc=new Scanner(System.in);
	
	//method for checking a amount
	public float aCheck(float amount) {
		while(true) {
			if(amount<=0) {
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter the amount again: ");
				amount = sc.nextInt();
			}
			else {
				return amount;
			}
		}
	}

	//method for checking a name
	public String Check(String name) {
		while(true) {
			if(Pattern.matches("[A-Za-z]*", name)){
				return name;
			}
			else {
				System.out.println("Invalid Name.");
				System.out.println("Enter the name again: ");
				name = sc.next();
			}
		}
	}

//		method for checking a mobile number
	public long mobCheck(long mob) { 
		while(true) {
			if(String.valueOf(mob).length() < 10) {
				System.out.println("Enter valid mobile number.");
				mob = sc.nextLong();
			}
			else {
				return mob;
			}
		}
	}

}
