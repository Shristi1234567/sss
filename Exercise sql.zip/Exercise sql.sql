                  
				  EXERCISE DATA QUERY LANGUAGE

1. select staff_name as "Staff Name",design_code as"Designation Code" from staff_master
	where (hiredate < '01-jan-2003') and staff_sal between 12000 and 25000;
	
2. select staff_code,staff_name,dept_code from staff_master
	where (months_between(sysdate,hiredate))>=216
	order by hiredate desc;
	
3. select * from staff_master 
	where mgr_code is null;
	
4. select * from book_master
	where book_pub_year between 2001 and 2004 and book_name like '%&%';
	
5. select staff_name from staff_master
	where staff_name like '%\_%' escape '\';
	
	
	              EXERCISE SINGLE ROW FUNCTION

1. 	select staff_name, '$' || staff_sal as Salary from staff_master;

2. select student_name , to_char(student_dob,'DY MONTH DD YYYY') as student_dob from student_master
	where TO_CHAR(student_dob,'DY') LIKE  ('%SAT%') or TO_CHAR(student_dob,'DY') LIKE  ('%SUN%') ;
	
3. select staff_name, round(months_between(sysdate,hiredate)) as "Months Worked" from staff_master;

4. select * from staff_master
	where  to_char(hiredate,'DD') between 1 and 15  and to_char(hiredate,'mon') like ('%dec%');
	
5. select staff_name,staff_sal,
	case 
		when staff_sal >= 50000 then 'A'
		when staff_sal >=25000 and staff_sal <50000 then 'B'
		when staff_sal >= 10000 and staff_sal < 25000 then 'C'
		else 'D'
	end 
	from staff_master;

	
6.	select staff_name,(to_char(hiredate,'DY DD-mon-YYYY')) as day from staff_master
	order by to_char(hiredate,'DAY') asc;

7. select instr('Mississippi','i',2,3) from dual;

8. 

9. select student_code,student_name,dept_code,
	decode(
		dept_code ,
		20 ,'Electricals',
		30 ,'Electronics',
			'Others')
	result
	from student_master
	order by dept_code;

	
					GROUP FUNCTIONS
					
1. select dept_code,round(max(staff_sal)) as Maximum,round(min(staff_sal)) as Minimum, round(sum(staff_sal)) as Total,
	round(avg(staff_sal)) as Average from staff_master
	group by dept_code;

	
2. select dept_code,count(mgr_code) as "Total Number of Managers" from staff_master
	group by dept_code;
	
				3. select deptno,sum(sal) as total from emp
					where empno ^= mgr 
					group by deptno ;


					JOINS AND SUBQUERIES
					
1. select staff_name,d.dept_code,d.dept_name,staff_sal from staff_master s
	inner join department_master d on s.dept_code=d.dept_code
	where staff_sal > 20000;
	
2. select staff_code as Staff#,staff_name as Staff,d.dept_name ,s.mgr_code as Mgr# from staff_master s
	inner join department_master d on s.dept_code=d.dept_code ;
	
3. select s.student_code,s.student_name,b.book_code,b.book_name from student_master s
	inner join book_transactions bt on s.student_code=bt.student_code
	inner join book_master b on bt.book_code=b.book_code
	where to_char(bt.book_expected_return_date,'DD-MM-YYYY') like to_char(sysdate,'DD-MM-YYYY');
	
4. select s.staff_code,s.staff_name,d.dept_name,de.design_name,b.book_code,b.book_name,bt.book_issue_date from department_master d
	inner join staff_master s on s.dept_code=d.dept_code
	inner join designation_master de on s.design_code=de.design_code
	inner join book_transactions bt on s.staff_code=bt.staff_code
	inner join book_master b on bt.book_code=b.book_code
	where  (sysdate-book_issue_date)<=30;
	
5. select s.staff_code,s.staff_name,d.dept_name,de.design_name,b.book_code,b.book_name,b.book_pub_author,	
	(round(sysdate - bt.book_expected_return_date) * 5) as fine from department_master d
	inner join staff_master s on s.dept_code=d.dept_code
	inner join designation_master de on s.design_code=de.design_code
	inner join book_transactions bt on s.staff_code=bt.staff_code
	inner join book_master b on bt.book_code=b.book_code;
	
6. select s.staff_code,s.staff_name,s.staff_sal from staff_master s
	where staff_sal<(select avg(s.staff_sal) from staff_master s);
	
7. select book_pub_author,book_name from book_master
	group by book_pub_author having count(book_pub_author)>1;
	
	
	where (select book_pub_author from book_master 
	where count(book_pub_author)>1);

8. select b.staff_code,s.staff_name,d.dept_name from staff_master s
	inner join department_master d on s.dept_code=d.dept_code
	inner join book_transactions b on s.staff_code=b.staff_code
	group by s.staff_code having count(s.staff_name)>1;
	
	
9. select s.student_code,s.student_name,d.dept_name from student_master s
	inner join department_master d on s.dept_code=d.dept_code
	where d.dept_code in (select max(count(d.dept_code)) from student_master group by d.dept_code );
	
10. select s.staff_code,s.staff_name,d.dept_name,de.design_name from staff_master s
	inner join department_master d on s.dept_code=d.dept_code 
	inner join designation_master de on s.design_code=de.design_code 
	where 
	
11. select ep.ename ,count(*) as "Total Strength" from emp e
	inner join emp ep on e.mgr=ep.empno
	group by ep.empno,ep.ename;
	
12.


13. select d.dept_code,d.dept_name,count(s.staff_name) as "No of People" from department_master d
	inner join staff_master s on d.dept_code=s.dept_code
	group by d.dept_code,d.dept_name;
	
	
							DATABASE OBJECTS

1. CREATE TABLE Customer(
	customerId number(5),
	Cust_Name varchar2(20),
	Address1 varchar2(30),
	Address2 varchar2(30)
	);
	
2. alter table Customer 
	rename column Cust_name to CustomerName varchar2(30);
	alter table Customer 
	modify  CustomerName varchar2(30) not null;
	
3. a) alter table Customer 
	add gender varchar2(1);
	alter table Customer
	add age number(3);
	alter table Customer
	add Phoneno number(10);
  b) alter table Customer
	rename to Cust_table;
	
4. insert into Cust_table 
	values (1000,'Allen','#115 Chicago','#115 Chicago','M',25,78787776);
	insert into Cust_table 
	values (1001,'George','#116 France','#116 France','M',25,434524);
	insert into Cust_table 
	values (1002,'Becker','#114 New YOrk','#114 New YOrk','M',45,431525);
	
5. alter table Cust_table
	add constraints custId_Prim primary key(customerId);
	
6. insert into Cust_table 
	values (1002,'John','#114 chicago','#114 chicago','M',45,439525);
	
	MESSAGE => unique constraint (SYSTEM.CUSTID_PRIM) violated
	
7. alter table cust_table
	disable constraints custId_prim ;
	insert into Cust_table 
	values (1002,'Becker','#114 New YOrk','#114 New YOrk','M',45,431525);
	insert into Cust_table 
	values (1003,'Nanapatekar','#115 India','#115 India','M',45,431525);

8. alter table cust_table
	enable constraints custId_prim ;
	
	MESSAGE=> ORA-02437: cannot validate (SYSTEM.CUSTID_PRIM) - primary key violated
	
9. ALTER TABLE Customer
	drop constraints CustId_prim;
	insert into Cust_table 
	values (1002,'Becker','#114 New YOrk','#114 New YOrk','M',45,431525,15000.50);
	insert into Cust_table 
	values (1003,'Nanapatekar','#115 India','#115 India','M',45,431525,20000.50);

10. truncate table cust_table;

11. alter table cust_table
	add E_mail varchar2(30);
	
12. alter table cust_table
	drop column E_mail;
	
13. create table suppliers(
	SuppID number(5),
	SName varchar2(20),
	Addr1 varchar2(30),
	Addr2 varchar2(30),
	Contactno number(10)
	);
	
14. drop table suppliers;
	
	create table CustomerMaster(
	customerId number(5) constraints Custid_PK primary key,
	customerName varchar2(30) not null,
	Address1 varchar2(30) not null,
	Address2 varchar2(30),
	gender varchar2(1),
	age number(3),
	phoneNo number(10)
	);









							
	
	
	
	
	
	

