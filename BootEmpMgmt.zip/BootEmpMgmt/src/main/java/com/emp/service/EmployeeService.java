package com.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.emp.model.Employee;
import com.emp.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Transactional
	public void insertEmployee(Employee employee) {
		employeeRepository.saveAndFlush(employee);
    }
	public Employee removeEmployee(int empId) {
		Optional<Employee> opt=employeeRepository.findById(empId);
		if(opt.isPresent())
		 {
			Employee emp=opt.get();
			employeeRepository.delete(emp);
		 }
		return null; 
	}
	
	public Employee findEmployee(int empId){
		Optional<Employee> opt=employeeRepository.findById(empId);
		if(opt.isPresent()) 
			return opt.get();	
		return null;
	}
	
	public List<Employee> getEmployoees(){
		return employeeRepository.findAll();
		
	}


	/*
	 * public Employee findEmployeeByCity(String city){ Employee
	 * e=employeeRepository.findByCity(city); if(e!=null) return e; return null; }
	 */

}
