package com.cg.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.jpa.model.Author;

public class AuthorDao {
	public void addAuthor(Author e)
	{
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform insert operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		em.getTransaction().begin();//begin the transaction
		em.persist(e);//persist is equal to insert query
		em.getTransaction().commit();//commit the transaction
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
	}
	}
	public void getAuthor(int id)
	{
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform retrieving operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		Author au=em.find(Author.class, id);
		if(au!=null)
		{
			System.out.println(au.getFirstName());
			System.out.println(au.getLastName());
			System.out.println(au.getMiddleName());
			System.out.println(au.getPhoneNo());
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
	}
	}
	public void updateAuthor(int id,String fname)
	{
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform updating operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		
		Author au=em.find(Author.class,id);
		if(au!=null)
		{
			em.getTransaction().begin();
			au.setFirstName(fname);
			em.getTransaction().commit();
		}
	
	
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		finally {
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
	}
	}
	public void deleteAuthor(int id)
	{
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try
		{
		//JPA logic to perform deleting operation
		emf=Persistence.createEntityManagerFactory("JPADemo1");//help us to connect with the database
		em=emf.createEntityManager();//manager to perform the operation
		Author au=em.find(Author.class, id);
		if(au!=null)
		{
			em.getTransaction().begin();
			em.remove(au);
			em.getTransaction().commit();
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null)
				em.close();//close the manager
				emf.close();//close the factory
	}	
	}

}
