package com.capg.bean;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name ="Wallet")
public class BankBean implements Serializable {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "my_seq_acc")
	@Column(length = 10)
	private long accNo;
	@Column(length = 30)
	private String name;
	@Column(length = 10)
	private long mobile;
	@Column(length = 10)
	private long balance;
	@Column(length = 20)
	private String password;
	@Column(length=5000)
	private String tran;

	public BankBean() {
	}

	public String getName() {
		return name;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTransaction(String tran) {
		this.tran = tran;
		
	}

	public long getMobile() {
		return mobile;
	}

	public long getAccNo() {
		return accNo;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long bal) {
		this.balance = bal;
	}

	public boolean getPassword(String password) {
		if (this.password.equals(password))
			return true;
		else
			return false;

	}

	public String getPassword1() {
		return password;

	}

	

	public BankBean(String name, long mobile, String password, long bal, String tan) {

		this.name = name;
		this.mobile = mobile;
		this.password = password;
		balance = bal;
		tran = tan;
		this.accNo = accNo;

	}

	public String getTran() {
		return tran;
	}

	public void setTran(String tran) {
		this.tran = tran;
	}

	public String getPassword() {
		return password;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "CreateAccount [ name=" + name + ",  mobile=" + mobile + ", balance=" + balance
				+ ", password=" + password + ", tran=" + tran + "]";
	}

	public void setPassword(String password) {
		this.password = password;
	}

}