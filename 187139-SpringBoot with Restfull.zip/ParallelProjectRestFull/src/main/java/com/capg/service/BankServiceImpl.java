package com.capg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.BankBean;
import com.capg.dao.BankRepo;
import com.capg.exception.BankException;


@Service
public class BankServiceImpl implements BankService {
	@Autowired
	BankRepo br;

	@Autowired
	BankService bs;

	@Override
	public List<BankBean> getAllAccounts() throws BankException{
		
		try {
			return br.findAll();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public BankBean createAccount(@Valid BankBean bean)throws BankException {
		
		try {
			bean.setBalance(1000);
			
			bean.setTran("\n    Deposited Amount is Rs.1000");
			br.save(bean);
			return bean;
		
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public BankBean getAccountByAccNo(@Valid long account)throws BankException {
		
		try {
			return br.findById(account).get();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public String getTransaction(@Valid long account)throws BankException {
		
		try {Optional<BankBean> optional=br.findById(account);
		
		BankBean product=optional.get();
		String s=product.getTran();
			return s;
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public List<BankBean> deleteAccount(@Valid long account) throws BankException{
		
		try {
			br.deleteById(account);
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
		return br.findAll();

	}

	@Override
	public BankBean depositAmount(@Valid long account,@Valid long amount, @Valid BankBean bean)throws BankException {
		
		try{Optional<BankBean> optional=br.findById(account);
		
		BankBean product=optional.get();
		product.setName(bean.getName());
		product.setMobile(bean.getMobile());
		product.setPassword(bean.getPassword());
		long bal=product.getBalance();
		long bal2=bal+amount;
		product.setBalance(bal2);
		String tran=product.getTran();
		product.setTran(tran+" \n   Credited Amount in  Rs." + amount);
		br.save(product);
		return product;
	

	
	} catch (Exception e) {
		throw new BankException(e.getMessage());
	}
	}

	@Override
	public BankBean withDrawAmount(@Valid long account, @Valid long amount,@Valid BankBean bean) throws BankException{
		
		try{Optional<BankBean> optional=br.findById(account);
	
			BankBean product=optional.get();
			product.setName(bean.getName());
			product.setMobile(bean.getMobile());
			product.setPassword(bean.getPassword());
			long bal=product.getBalance();
			long bal2=bal-amount;
			product.setBalance(bal2);
			String tran=product.getTran();
			product.setTran(tran+" \n   Debited Amount in Rs." + amount);
		br.save(product);
			return product;
		
		
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public long getBalance(@Valid long account) throws BankException {
		
		try {
			Optional<BankBean> optional=br.findById(account);
			
			BankBean product=optional.get();
			long bal= product.getBalance();
			return bal;
		} catch (Exception ex) {
			throw new BankException("Invalid Account number");
		}
	}

	@Override
	public List<BankBean> transferAmount(@Valid long account, @Valid long account1,@Valid long amount)throws BankException {
		
		try{Optional<BankBean> optional=br.findById(account);
		Optional<BankBean> optional1=br.findById(account1);
		BankBean product=optional.get();
		BankBean product1=optional1.get();
		product.setName(product.getName());
		product.setMobile(product.getMobile());
		product.setPassword(product.getPassword());
		long bal=product.getBalance();
		long bal2=bal-amount;
		product.setBalance(bal2);
		String tran=product.getTran();
		
		product.setTran(tran+" \n   Debited Amount in Rs." + amount);
		
		
        br.save(product);
		product1.setName(product1.getName());
		product1.setMobile(product1.getMobile());
		product1.setPassword(product1.getPassword());
		long bal4=product1.getBalance();
		long bal3=bal4+amount;
		product1.setBalance(bal3);
		String tran2=product1.getTran();
	
		product1.setTran(tran2+" \n    Debited Amount in  Rs." + amount);
		
		br.save(product1);
		List<BankBean> l1 =new ArrayList<BankBean>() ;
		l1.add(product);
		l1.add(product1);
		return l1;
	
	} catch (Exception e) {
		throw new BankException(e.getMessage());
	}
	}

	

}
