package com.capg.service;

import java.util.List;

import javax.validation.Valid;

import com.capg.bean.BankBean;
import com.capg.exception.BankException;

public interface BankService {
	
	public List<BankBean> getAllAccounts() throws BankException;
	public BankBean createAccount(@Valid BankBean bean)throws BankException;
	public BankBean getAccountByAccNo(@Valid long account)throws BankException;
	public String getTransaction(@Valid long account)throws BankException;
	public List<BankBean> deleteAccount(@Valid long account)throws BankException;
	public BankBean depositAmount(@Valid long account, @Valid long amount,@Valid BankBean bean)throws BankException;
	public BankBean withDrawAmount(@Valid long account, @Valid long amount,@Valid BankBean bean)throws BankException;
	public long getBalance(@Valid long account) throws BankException;
	public List<BankBean> transferAmount(@Valid long account, @Valid long account1,@Valid long amount) throws BankException;
	

}
