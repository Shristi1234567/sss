package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.BankBean;
import com.capg.exception.BankException;
import com.capg.service.BankService;


@RestController

@RequestMapping("/users")
public class BankController {
	@Autowired
	BankService bs;
	@RequestMapping("/All")
	public List<BankBean> getAllAccounts() throws BankException {
		return bs.getAllAccounts();
	}

	
	@PostMapping(value = "/create")
	public BankBean createAccount(@Valid @RequestBody BankBean bean) throws BankException {
		return bs.createAccount(bean);
	}
	
	@GetMapping("/printDetails/{account}")
	public BankBean getAccountByAccNo(@Valid @PathVariable long account) throws BankException {
		return bs.getAccountByAccNo(account);
	}

	@GetMapping("/printTransaction/{account}")
	public ResponseEntity<String> getTransaction(@Valid @PathVariable long account) throws BankException {
		String s=bs.getTransaction(account);
		return new ResponseEntity<String> (s,HttpStatus.OK);
	}

	
	@GetMapping("/showBalance/{account}")
	public ResponseEntity<String> getBalance(@Valid @PathVariable long account) throws BankException {
		long l=bs.getBalance(account);
		return new ResponseEntity<String> ("Your Account Balance is Rs."+l,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/delete/{account}")
	public List<BankBean> deleteAccount(@Valid @PathVariable long account) throws BankException {
		return bs.deleteAccount(account);

	}
	
	@PutMapping("/deposit/{account}/{amount}")
	public BankBean depositAmount(@Valid @PathVariable long account, @Valid @PathVariable long amount,
			@Valid @RequestBody BankBean bean) throws BankException {
		return bs.depositAmount(account, amount, bean);
	}
	
	@PutMapping("/withdraw/{account}/{amount}")
	public BankBean withdrawAmount(@Valid @PathVariable long account, @Valid @PathVariable long amount,
			@Valid @RequestBody BankBean bean) throws BankException {
		return bs.withDrawAmount(account, amount, bean);
	}

	@PutMapping("/fundTransfer/{account}/{account1}/{amount}")
	public List<BankBean> transferAmount(@Valid @PathVariable long account, @Valid  @PathVariable long account1 ,@Valid  @PathVariable long amount )
			throws BankException {
		return bs.transferAmount(account, account1,amount);
	} 
	 
}