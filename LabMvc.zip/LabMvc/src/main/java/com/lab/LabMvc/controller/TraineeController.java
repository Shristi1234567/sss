package com.lab.LabMvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.lab.LabMvc.model.Trainee;
import com.lab.LabMvc.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService service;

	
	
	@RequestMapping("/home")
	public String home() {
		System.out.println("inside home");
		return "home";
	}
   
	@RequestMapping("/login")
	public String login() {
		System.out.println("inside login");
		return "login";
	}
    
	@RequestMapping(value="/addTrainee", method=RequestMethod.GET) 
	  public  ModelAndView loadAddTrainee() {
	  
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("addTrainee"); 
		  mav.addObject("train", new Trainee()); 
		  return mav; 
	  }
	
	@RequestMapping(value="/addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("train") Trainee train) {
		
		service.insertTrainee(train);
		ModelAndView mav = new ModelAndView("addTrainee");
		String msg = "Trainee Added Successfully with trainee id "+train.getTraineeId();
		mav.addObject("SuccessMessage", msg);
		return mav;
	}
	
	@RequestMapping(value="/retAllTrainee", method=RequestMethod.GET)
	public ModelAndView getTrainees() {
		List<Trainee> trainlist = service.getTrainees();
		ModelAndView mav = new ModelAndView("retAllTrainee");
		if(trainlist.isEmpty()) {
			mav.addObject("errorMessage", "Employee details not found");			
		}
		else {
			mav.addObject("trainList",trainlist);			
		}
		
		return mav;
	}
	
	
	@RequestMapping(value="/retTrainee", method=RequestMethod.GET)
	public ModelAndView loadGetTraineeById() {			
		ModelAndView mav = new ModelAndView("retTrainee");		
		return mav;
	}
	
	@RequestMapping(value="/retTrainee", method=RequestMethod.POST)
	public ModelAndView getTraineeById(@RequestParam Integer traineeId) {
		Trainee e = service.findTrainee(traineeId);
		System.out.println("found = "+e);
		ModelAndView mav = new ModelAndView("retTrainee");	
		
		if(e!=null) {
			mav.addObject("train", e);
		}
		else
			mav.addObject("ErrorMessage","Employee details not found for the given employee id");
		
		return mav;
	}
	@RequestMapping(value="delTraineeById",method=RequestMethod.GET)
	public ModelAndView removeTrainee() {
		
		ModelAndView mav=new ModelAndView("delTraineeById");
		return mav;
		
	}
	
	@RequestMapping(value="delTraineeById" ,method=RequestMethod.POST)
    public ModelAndView delTraineeById(@RequestParam Integer traineeId) {
		Trainee e=service.findTrainee(traineeId);
		ModelAndView mav=new ModelAndView("delTraineeById");
		if(e!=null) {
			service.removeTrainee(traineeId);
		    String msg="Trainee deleted succesfully";
		    mav.addObject("SuccessMessage",msg);
		}
		else {
			String msg="Trainee details not found";
			mav.addObject("ErrorMessage",msg);
		}
		
		return mav;
		
	}
	
	@RequestMapping(value="/updateTrainee", method=RequestMethod.GET)
	public ModelAndView loadUpdateEmployee() {			
		ModelAndView mav = new ModelAndView("updateTrainee");	
		mav.addObject("train", new Trainee());
		return mav;
	}
	  @RequestMapping(value="/updateTrainee", method=RequestMethod.POST) 
	  public ModelAndView updateEmployee(@ModelAttribute("train")Trainee train)
	  { 
		  service.updateTrainee(train);
		  System.out.println("found = "+train);
		  System.out.println("inside update");
		  
		  ModelAndView mav=new ModelAndView("updateTrainee");
	      String msg="Employee updated successfully";
	      mav.addObject("SuccessMessage",msg);
	      return mav;
	  }
	
}
